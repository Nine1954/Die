package com.phobia;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, Phobia.MODID);

    // Played when stamina runs out. File: assets/phobia/sounds/out_of_stamina.ogg
    public static final DeferredHolder<SoundEvent, SoundEvent> OUT_OF_STAMINA = SOUNDS.register(
            "out_of_stamina",
            () -> SoundEvent.createVariableRangeEvent(
                    ResourceLocation.fromNamespaceAndPath(Phobia.MODID, "out_of_stamina")));
}
