package com.phobia;

import java.util.Locale;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.GameType;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.CommandEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(modid = Phobia.MODID)
public class ServerEvents {

    private static final ResourceLocation EXHAUSTED_MOD =
            ResourceLocation.fromNamespaceAndPath(Phobia.MODID, "exhausted_sprint");
    // Sprinting is +30% speed. This cancels it and leaves 85% of normal walking speed.
    private static final double EXHAUSTED_AMOUNT = 0.85 / 1.3 - 1.0;

    private static final ResourceKey<DamageType> DARK_FIGURE = ResourceKey.create(
            Registries.DAMAGE_TYPE, ResourceLocation.fromNamespaceAndPath(Phobia.MODID, "dark_figure"));
    private static final int GRAB_TICKS = 100;

    // ------------------------------------------------------------------ tick

    @SubscribeEvent
    public static void onPlayerPre(PlayerTickEvent.Pre e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        PlayerStats s = sp.getData(Phobia.STATS);

        // Sprinting should not cost food. Undo the exhaustion that sprint movement added since last tick.
        // (Approximate: only while on the ground, so jumping still costs food like normal.)
        var food = sp.getFoodData();
        float cur = food.getExhaustionLevel();
        if (s.lastSprinting && sp.onGround() && cur > s.lastExhaustion) {
            food.setExhaustion(s.lastExhaustion);
        }
    }

    @SubscribeEvent
    public static void onPlayerPost(PlayerTickEvent.Post e) {
        if (!(e.getEntity() instanceof ServerPlayer sp) || !sp.isAlive()) return;
        PlayerStats s = sp.getData(Phobia.STATS);

        tickCheatGrab(sp, s);

        if (sp.isCreative() || sp.isSpectator()) {
            s.exhausted = false;
            setExhaustedSlow(sp, false);
        } else {
            tickStamina(sp, s);
            if (++s.secondTimer >= 20) {
                s.secondTimer = 0;
                tickSanity(sp, s);
            }
        }

        s.lastExhaustion = sp.getFoodData().getExhaustionLevel();
        s.lastSprinting = sp.isSprinting();
        syncIfChanged(sp, s);
    }

    // --------------------------------------------------------------- stamina

    private static void tickStamina(ServerPlayer sp, PlayerStats s) {
        final float dt = 1f / 20f;
        float max = PhobiaConfig.STAMINA_MAX.get().floatValue();
        float penalty = PhobiaConfig.SANITY_STAMINA_PENALTY.get().floatValue();
        float factor = 1f + (1f - s.sanity / 100f) * penalty; // 1.0 at full sanity

        if (s.stamina > max) s.stamina = max;

        boolean sprinting = sp.isSprinting();
        if (sprinting && !s.exhausted) {
            s.stamina -= PhobiaConfig.STAMINA_LOSS.get().floatValue() * dt * factor;
            if (s.stamina <= 0f) {
                s.stamina = 0f;
                s.exhausted = true;
                // Gasp once when stamina runs out (nearby players hear it too)
                sp.level().playSound(null, sp.getX(), sp.getY(), sp.getZ(),
                        ModSounds.OUT_OF_STAMINA.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
            }
        } else {
            float gain = PhobiaConfig.STAMINA_GAIN.get().floatValue() * dt / factor;
            if (sprinting) gain *= 0.5f; // still holding sprint while exhausted: recover slower
            s.stamina = Math.min(max, s.stamina + gain);
            if (s.exhausted && s.stamina >= PhobiaConfig.STAMINA_RESUME.get().floatValue()) {
                s.exhausted = false;
            }
        }

        setExhaustedSlow(sp, s.exhausted && sprinting);
    }

    private static void setExhaustedSlow(ServerPlayer sp, boolean on) {
        AttributeInstance speed = sp.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed == null) return;
        boolean has = speed.hasModifier(EXHAUSTED_MOD);
        if (on && !has) {
            speed.addTransientModifier(new AttributeModifier(
                    EXHAUSTED_MOD, EXHAUSTED_AMOUNT, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        } else if (!on && has) {
            speed.removeModifier(EXHAUSTED_MOD);
        }
    }

    // ---------------------------------------------------------------- sanity

    private static void tickSanity(ServerPlayer sp, PlayerStats s) {
        ServerLevel level = sp.serverLevel();
        BlockPos pos = sp.blockPosition();

        boolean dark = level.getMaxLocalRawBrightness(pos) <= PhobiaConfig.DARK_LIGHT_LEVEL.get();
        boolean tight = isTight(level, pos);
        int range = PhobiaConfig.BIRD_RANGE.get();
        int birds = level.getEntitiesOfClass(LivingEntity.class,
                sp.getBoundingBox().inflate(range), en -> en.getType().is(ModTags.BIRDS)).size();

        float delta = 0f;
        if (dark) delta -= PhobiaConfig.DARK_LOSS.get().floatValue();
        if (tight) delta -= PhobiaConfig.TIGHT_LOSS.get().floatValue();
        if (birds > 0) delta -= Math.min(birds, 5) * PhobiaConfig.BIRD_LOSS.get().floatValue();
        if (!dark && !tight && birds == 0) delta = PhobiaConfig.RECOVER.get().floatValue();

        s.sanity = Math.max(0f, Math.min(100f, s.sanity + delta));
    }

    // Counts free (non-colliding) cells in a 5x5 area at feet and head height.
    // A 1-wide tunnel has about 10 free cells, an open room about 50.
    private static boolean isTight(ServerLevel level, BlockPos origin) {
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        int free = 0;
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                for (int dy = 0; dy <= 1; dy++) {
                    m.set(origin.getX() + dx, origin.getY() + dy, origin.getZ() + dz);
                    if (level.getBlockState(m).getCollisionShape(level, m).isEmpty()) free++;
                }
            }
        }
        return free <= PhobiaConfig.TIGHT_MAX_FREE.get();
    }

    // ------------------------------------------------------------------ sync

    private static void syncIfChanged(ServerPlayer sp, PlayerStats s) {
        float max = PhobiaConfig.STAMINA_MAX.get().floatValue();
        boolean edge = (s.stamina >= max || s.stamina <= 0f) && s.stamina != s.sentStamina;
        if (edge
                || Math.abs(s.stamina - s.sentStamina) >= 1f
                || Math.abs(s.sanity - s.sentSanity) >= 0.5f
                || s.exhausted != s.sentExhausted
                || max != s.sentMax) {
            send(sp, s);
        }
    }

    public static void send(ServerPlayer sp, PlayerStats s) {
        float max = PhobiaConfig.STAMINA_MAX.get().floatValue();
        s.sentSanity = s.sanity;
        s.sentStamina = s.stamina;
        s.sentMax = max;
        s.sentExhausted = s.exhausted;
        PacketDistributor.sendToPlayer(sp, new StatsPayload(s.sanity, s.stamina, max, s.exhausted));
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) send(sp, sp.getData(Phobia.STATS));
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) send(sp, sp.getData(Phobia.STATS));
    }

    // ------------------------------------------------------------ anti-cheat

    @SubscribeEvent
    public static void onCommand(CommandEvent e) {
        CommandSourceStack src = e.getParseResults().getContext().getSource();
        if (!(src.getEntity() instanceof ServerPlayer sp)) return; // console / command blocks are ignored
        if (PhobiaConfig.ANTICHEAT_MODE.get() == PhobiaConfig.CheatMode.OFF) return;
        if (sp.server.isDedicatedServer() && !PhobiaConfig.ANTICHEAT_DEDICATED.get()) return;

        String raw = e.getParseResults().getReader().getString().trim();
        if (raw.startsWith("/")) raw = raw.substring(1);
        String name = raw.split("\\s+")[0].toLowerCase(Locale.ROOT);
        if (name.startsWith("minecraft:")) name = name.substring("minecraft:".length());

        if (PhobiaConfig.CHEAT_COMMANDS.get().contains(name)) {
            e.setCanceled(true);
            PlayerStats s = sp.getData(Phobia.STATS);
            if (s.cheatTicks < 0) s.cheatTicks = 0;
        }
    }

    // 5 second "grab" sequence: darkness, heartbeat, lifted into the air, then the punishment.
    private static void tickCheatGrab(ServerPlayer sp, PlayerStats s) {
        if (s.cheatTicks < 0) return;
        int t = s.cheatTicks++;

        if (t == 0) {
            sp.setGameMode(GameType.SURVIVAL);
            sp.addEffect(new MobEffectInstance(MobEffects.DARKNESS, GRAB_TICKS + 40, 0, false, false, false));
            sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, GRAB_TICKS + 40, 4, false, false, false));
        }
        if (t % 25 == 0) {
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.WARDEN_HEARTBEAT,
                    SoundSource.HOSTILE, 2.0f, 0.5f);
        }
        if (t >= 20 && t < GRAB_TICKS) {
            sp.setNoGravity(true);
            sp.setDeltaMovement(0.0, 0.05, 0.0);
            sp.hurtMarked = true;
        }
        if (t >= GRAB_TICKS) {
            sp.setNoGravity(false);
            s.cheatTicks = -1;
            if (PhobiaConfig.ANTICHEAT_MODE.get() == PhobiaConfig.CheatMode.KICK) {
                sp.connection.disconnect(Component.translatable("phobia.cheat.kick"));
            } else {
                Holder<DamageType> type = sp.level().registryAccess()
                        .registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DARK_FIGURE);
                sp.hurt(new DamageSource(type), Float.MAX_VALUE);
            }
        }
    }
}
